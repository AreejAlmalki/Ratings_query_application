public class RatingManager {
	// Constructor
	public RatingManager();
	
	// Read ratings from a file and create a RatingManager object that stores these ratings. The ratings must be inserted in their order of appearance in the file.
	public static RatingManager read(String fileName);

	// Add a rating
	public void addRating(Rating rating);

	// Return all ratings given by user i. 
	public LinkedList<Rating> getUserRatings(int i);

	// Return all ratings given to item j
	public LinkedList<Rating> getItemRatings(int j);

	// Return the list of highest rated items
	public LinkedList<Integer> getHighestRatedItems();

	// Return the average rating of item j. If i has no ratings, -1 is returned
	public double getAverageItemRating(int j);

	// Return the average rating given by user i. If i has no ratings, -1 is returned
	public double getAverageUserRating(int i);
	//***************************************************************************

	// Return the rating of user i for item j. If there is no rating, -1 is returned.
	public int getRating(int i, int j);

	// Return the number of keys to compare with in order to find the rating of user i for item j.
	public int nbComp(int i, int j);

	// Compute the distance between the two users ui and uj. If ui and uj have no common item in their ratings, then Double.POSITIVE_INFINITY is returned.
	public double getDist(int ui, int uj);

	// Return a list of at most k nearest neighbors to user i from a list of users. User i and users at infinite distance should not be included (the number of users returned can therefore be less than k).
	public LinkedList<Integer> kNNUsers(int i, LinkedList<Integer> users, int k);

	// Return the average rating given to item j by a list of users. If the list users is empty or non of the users it contains rated item j, then the global average rating of item j (as computed by getAverageItemRating(j)) is returned.
	public double getAverageRating(int j, LinkedList<Integer> users);

	// Return an estimation of the rating given by user i for item j using k nearest neighbor users.
	public double getEstimatedRating(int i, int j, int k) 		int r = getRating(i, j);
		if (r != -1) {
			return r;
		}
		LinkedList<Rating> ratings = getItemRatings(j);
		LinkedList<Integer> users = new LinkedList<Integer>();
		if ((ratings != null) && !ratings.empty()) {
			ratings.findFirst();
			while (!ratings.last()) {
				users.insert(ratings.retrieve().getUserId());
				ratings.findNext();
			}
			users.insert(ratings.retrieve().getUserId());
		}
		LinkedList<Integer> knn = kNNUsers(i, users, k);
		return getAverageRating(j, knn);
	}
}
