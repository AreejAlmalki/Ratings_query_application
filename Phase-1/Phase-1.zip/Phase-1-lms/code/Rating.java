public class Rating {
	private int userId;
	private int itemId;
	private int value; // The value of the rating
	
	// Constructor
	public Rating(int userId, int itemId, int value);
	
	// Getters... (No setters. This class is immutable)
}
